<?php
session_start(); // Inicie a sessão, se ainda não estiver iniciada

// Destrua a sessão (isso irá desconectar o usuário)
session_destroy();

// Redirecione o usuário para a página de login ou para a página inicial, por exemplo:
header("Location: index.php"); // Substitua "index.php" pelo caminho adequado
exit;
?>