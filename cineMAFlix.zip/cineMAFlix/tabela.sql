create database cadastroUsuario;
use cadastroUsuario;
create table usuario (
nome varchar(255),
email varchar(255) primary key,
senha varchar(255));
select * from usuario;
create database cafebistro;

CREATE TABLE filmes (
    id INT NOT NULL AUTO_INCREMENT, 
    genero VARCHAR(45) NOT NULL, 
    nome VARCHAR(45) NOT NULL, 
    sinopse VARCHAR(90) NOT NULL, 
    imagem VARCHAR(80) NOT NULL, 
    preco DECIMAL (5,2) NOT NULL, 
PRIMARY KEY (id));

INSERT INTO filmes (genero, nome, sinopse, imagem, ) VALUES ('Ação', 'Clube da Luta', 'Café cremoso irresistivelmente suave e que envolve seu paladar', 'clubedaluta.jpg', '');
INSERT INTO filmes (genero, nome, sinopse, imagem, preco) VALUES ('Terror', 'A hora do pesadelo', 'Um grupo de adolescentes é atacado por um assassino que só pode ser morto no mundo dos sonhos. O assassino é Freddy Krueger, um homem que foi queimado vivo por pais de crianças que ele molestou.Os adolescentes precisam descobrir como derrotar Freddy no mundo dos sonhos, ou ele vai matar todos eles.', 'ahoradopesadelo.jpg', '2.00');
INSERT INTO filmes (genero, nome, sinopse, imagem, preco) VALUES ('Comédia', 'Esqueceram de mim', 'Sozinho em casa é uma série de filmes americanos de comédia familiar de Natal originalmente criados por John Hughes e dirigidos por Chris Columbus, Raja Gosnell, Rod Daniel, Peter Hewitt e Dan Mazer.', 'esqueceramdemim.jpg', '7.00');
INSERT INTO filmes (genero, nome, sinopse, imagem, preco) VALUES ('Ação', 'De volta pro futuro', 'Café gelado refrescante, adoçado e com notas sutis de baunilha ou caramelo.', 'cafe-gelado.jpg', '3.00');
INSERT INTO filmes (genero, nome, sinopse, imagem, preco) VALUES ('Romance', 'Titanic', 'Um artista pobre e uma jovem rica se conhecem e se apaixonam na fatídica viagem inaugural do Titanic em 1912. Embora esteja noiva do arrogante herdeiro de uma siderúrgica, a jovem desafia sua família e amigos em busca do verdadeiro amor.', 'titanic.jpg', '24.99');
INSERT INTO filmes (genero, nome, sinopse, imagem, preco) VALUES ('Animação', 'Rei Leão', 'Este desenho animado da Disney mostra as aventuras de um leão jovem de nome Simba, o herdeiro de seu pai, Mufasa. O tio malvado de Simba, Oscar, planeja roubar o trono de Mufasa atraindo pai e filho para uma emboscada. Simba consegue escapar e somente Mufasa morre. Com a ajuda de seus amigos,Timon e Pumba, ele reaparece como adulto para recuperar sua terra, que foi roubada por seu tio Oscar.', 'oreileao.jpg', '23.00');
INSERT INTO filmes (genero, nome, sinopse, imagem, preco) VALUES ('Ficção', 'Matrix', 'Prato italiano autêntico da massa do fettuccine com peito de frango grelhado', 'fettuccine.jpg', '22.50');
INSERT INTO filmes (genero, nome, sinopse, imagem, preco) VALUES ('Animação', 'Branca de Neve', 'A rainha malvada morre de ciúmes da beleza de Branca de Neve e manda mata-la. Logo, descobre que a jovem não morreu e está morando na floresta com sete amiguinhos. A princesa então é envenenada pela rainha e só o beijo de um príncipe pode salvá-la.', 'brancade-neve.jpg', '22.50');

/*update filmes set imagem = 'img/cafe-cremoso.jpg' where id = 1;
update filmes set imagem = 'img/cafe-com-leite.jpg' where id = 2;
update filmes set imagem = 'img/cappuccino.jpg' where id = 3;
update filmes set imagem = 'img/cafe-gelado.jpg' where id = 4;
update filmes set imagem = 'img/bife.jpg' where id = 5;
update filmes set imagem = 'img/prato-peixe.jpg' where id = 6;
update filmes set imagem = 'img/prato-frango.jpg' where id = 7;
update filmes set imagem = 'img/fettuccine.jpg' where id = 8;
*/
select * from filmes;
#delete from filmes where id >33;
update filmes set imagem = concat("../img/",imagem) where id= 33;

select * from usuario;


alter table usuario add perfil varchar(50) default(0);
update usuario set perfil = 'admin' where email = 'abc@ifsp.edu.br';