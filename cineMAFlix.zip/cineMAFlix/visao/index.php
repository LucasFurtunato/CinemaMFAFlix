<!DOCTYPE html>
<html lang="pt-br">
<?php 
  session_start();
  
  if (isset($_SESSION["usuario"])) {
    $usuario = $_SESSION["usuario"] ;

include '..\repositorio\conexao.php';
include '..\modelo\Catalogo.php';
include '..\repositorio\CatalogoRepositorio.php';

$filmesRepositorio = new FilmeRepositorio($conn);
$horrores = $filmesRepositorio->listarTerror();
$romances = $filmesRepositorio->listarRomances();
$acoes = $filmesRepositorio->listarAcao();
$ficcoes = $filmesRepositorio->listarFiccao();
$animacoes = $filmesRepositorio->listarAnimacao();
}
?>
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>CineMAFlix - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../assets/img/favicon.png" rel="icon">
  <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Selecao
  * Updated: Aug 30 2023 with Bootstrap v5.3.1
  * Template URL: https://bootstrapmade.com/selecao-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  <style>
  .portfolio-img img {
    max-width: 100%; /* Define um tamanho máximo para a imagem */
    height: auto; /* Mantém a proporção da imagem */
  }
  .portfolio-img img {
      max-width: 100%;
      height: auto;
    }
</style>
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center  header-transparent ">
    <div class="container d-flex align-items-center justify-content-between">

      <div class="logo">
        <h1><a href="index.html">CineMAFlix</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="../assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li class="dropdown">
            <?php
              if (isset($_SESSION["usuario"])) 
              {?>
                <a href="#">
                  <span>
                    <?php
                      echo $usuario;
                    ?>
                  </span>
                  <i class="bi bi-chevron-down"></i>
                </a>
                <ul>
                  <li><a href="../visao/admin.php">admin</a></li>
                  <li><a href="../controladora/logout.php">sair</a></li>
                </ul>
              <?php
              }
              else
              {?>
                <a href="../visao/login.php">
                  Login
                </a>
              <?php
              }
            ?>
          </li>
          <li class="dropdown"><a href="#"><span>Home</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a class="nav-link scrollto" href="#about">About</a></li>
              <li><a class="nav-link scrollto" href="#services">Services</a></li>
              <li><a class="nav-link scrollto " href="#portfolio">Filmes</a></li>
              <li><a class="nav-link scrollto" href="#pricing">Pricing</a></li>
              <li><a class="nav-link scrollto" href="#team">Team</a></li>
            </ul>
          </li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-end align-items-center">
    <div id="heroCarousel" data-bs-interval="5000" class="container carousel carousel-fade" data-bs-ride="carousel">

      <!-- Slide 1 -->
      <div class="carousel-item active">
        <div class="carousel-container">
          <img src="../assets/img/titanic.jpg" >
          <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Read More</a>
        </div>
      </div>

      <!-- Slide 2 -->
      <div class="carousel-item">
        <div class="carousel-container">
          <img src="../assets/img/ClubeDaLuta.png" width="370">
          <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Read More</a>
        </div>
      </div>

      <!-- Slide 3 -->
      <div class="carousel-item">
        <div class="carousel-container">
          <img src="../assets/img/pulp-fiction.jpeg" width="340">
          <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Read More</a>
        </div>
      </div>

      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon bx bx-chevron-left" aria-hidden="true"></span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon bx bx-chevron-right" aria-hidden="true"></span>
      </a>

    </div>

    <svg class="hero-waves" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 24 150 28 " preserveAspectRatio="none">
      <defs>
        <path id="wave-path" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z">
      </defs>
      <g class="wave1">
        <use xlink:href="#wave-path" x="50" y="3" fill="rgba(255,255,255, .1)">
      </g>
      <g class="wave2">
        <use xlink:href="#wave-path" x="50" y="0" fill="rgba(255,255,255, .2)">
      </g>
      <g class="wave3">
        <use xlink:href="#wave-path" x="50" y="9" fill="#fff">
      </g>
    </svg>

  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="section-title" data-aos="zoom-out">
          <h2>Em cartaz</h2>
          <p>Filmes em cartaz</p>
        </div>


      </div>
    </section><!-- End About Section -->

    <!-- ======= Features Section ======= -->
    <section id="features" class="features">
      <div class="container">

        <ul class="nav nav-tabs row d-flex">
          <li class="nav-item col-3" data-aos="zoom-in">
            <a class="nav-link active show" data-bs-toggle="tab" href="#tab-1">
              
              <h4 class="d-none d-lg-block">Titanic</h4>
            </a>
          </li>
          <li class="nav-item col-3" data-aos="zoom-in" data-aos-delay="100">
            <a class="nav-link" data-bs-toggle="tab" href="#tab-2">
              
              <h4 class="d-none d-lg-block">Clube da Luta</h4>
            </a>
          </li>
          <li class="nav-item col-3" data-aos="zoom-in" data-aos-delay="200">
            <a class="nav-link" data-bs-toggle="tab" href="#tab-3">
              
              <h4 class="d-none d-lg-block">Pulp Fiction</h4>
            </a>
          </li>
        </ul>

        <div class="tab-content" data-aos="fade-up">
          <div class="tab-pane active show" id="tab-1">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0">
              <h3>Sinopse</h3>
                <p>
                Um artista pobre e uma jovem rica se conhecem e se apaixonam na fatídica viagem inaugural do Titanic em 1912. 
                  Embora esteja noiva do arrogante herdeiro de uma siderúrgica, a jovem desafia sua família e amigos em busca do verdadeiro amor.
                </p>
                <p class="fst-italic">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                  magna aliqua.
                </p>
                <ul>
                  <li><i class="ri-check-double-line"></i>Gênero: Romance/Drama</li>
                  <li><i class="ri-check-double-line"></i>Duração:  3h 14m</li>
                  <li><i class="ri-check-double-line"></i>Diretor: James Cameron</li>
                  <li><i class="ri-check-double-line"></i>Classificação: 12 anos</li>
                  
                </ul>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center">
                <img src="../../assets/img/features-1.png" alt="" class="img-fluid">
              </div>
            </div>
          </div>
          <div class="tab-pane" id="tab-2">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0">
                <h3>Sinopse</h3>
                <p>
                Um homem deprimido que sofre de insônia conhece um estranho vendedor chamado Tyler Durden e se vê morando em uma casa suja depois que seu perfeito 
                apartamento é destruído.A dupla forma um clube com regras rígidas onde homens lutam. A parceria perfeita é comprometida quando uma mulher, Marla,
                atrai a atenção de Tyler.
                
                </p>
                <p class="fst-italic">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                  magna aliqua.
                </p>
                <ul>
                <li><i class="ri-check-double-line"></i>Gênero: Suspense/Drama</li>
                  <li><i class="ri-check-double-line"></i>Duração:  2h 19m</li>
                  <li><i class="ri-check-double-line"></i>Diretor: David Fincher</li>
                  <li><i class="ri-check-double-line"></i>Classificação: 18 anos</li>
                </ul>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center">
                <img src="../../assets/img/features-2.png" alt="" class="img-fluid">
              </div>
            </div>
          </div>
          <div class="tab-pane" id="tab-3">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0">
                <h3>Sinopse</h3>
                <p>
                Assassino que trabalha para a máfia se apaixona pela esposa de seu chefe quando é convidado a acompanhá-la, um boxeador descumpre sua promessa de perder uma
                luta e um casal tenta um assalto que rapidamente sai do controle. 
                </p>
                <ul>
                <li><i class="ri-check-double-line"></i>Gênero: Independente/Drama</li>
                <li><i class="ri-check-double-line"></i>Duração:  2h 34m</li>
                <li><i class="ri-check-double-line"></i>Diretor: Quentin Tarantino</li>
                <li><i class="ri-check-double-line"></i>Classificação: 18 anos</li>
                </ul>
                <p class="fst-italic">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                  magna aliqua.
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center">
                <img src="../../assets/img/features-3.png" alt="" class="img-fluid">
              </div>
            </div>
          </div>
          <div class="tab-pane" id="tab-4">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0">
                <h3>Sinopse</h3>
                <p>
                  Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
                  velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                  culpa qui officia deserunt mollit anim id est laborum
                </p>
                <p class="fst-italic">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                  magna aliqua.
                </p>
                <ul>
                  <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
                  <li><i class="ri-check-double-line"></i> Duis aute irure dolor in reprehenderit in voluptate velit.</li>
                  <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate trideta storacalaperda mastiro dolore eu fugiat nulla pariatur.</li>
                </ul>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center">
                <img src="../../assets/img/features-4.png" alt="" class="img-fluid">
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Features Section -->

    <!-- ======= Cta Section ======= -->
    <section id="cta" class="cta">
      <div class="container">

        <div class="row" data-aos="zoom-out">
          <div class="col-lg-9 text-center text-lg-start">
            <h3>Call To Action</h3>
            <p> Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
          </div>
          <div class="col-lg-3 cta-btn-container text-center">
            <a class="cta-btn align-middle" href="#">Call To Action</a>
          </div>
        </div>

      </div>
    </section><!-- End Cta Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container">

        <div class="section-title" data-aos="zoom-out">
          <h2>Services</h2>
          <p>Aperitivos</p>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6">
            <div class="icon-box" data-aos="zoom-in-left">
              <div class="icon"><i class="bi-briefcase class: pipoca"></i></i></div>
              <h4 class="title"><a href="">Pipoca</a></h4>
              <p class="description">Balde de pipoca - R$20,00</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mt-5 mt-md-0">
            <div class="icon-box" data-aos="zoom-in-left" data-aos-delay="100">
              <div class="icon"><i class="bi bi-book" style="color: #e9bf06;"></i></div>
              <h4 class="title"><a href="">Onion rings</a></h4>
              <p class="description">Balde de onion rings - 15,00</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mt-5 mt-lg-0 ">
            <div class="icon-box" data-aos="zoom-in-left" data-aos-delay="200">
              <div class="icon"><i class="bi bi-card-checklist" style="color: #3fcdc7;"></i></div>
              <h4 class="title"><a href="">Coxinha</a></h4>
              <p class="description">Balde de  coxinha - R$30,00 </p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mt-5">
            <div class="icon-box" data-aos="zoom-in-left" data-aos-delay="300">
              <div class="icon"><i class="bi bi-binoculars" style="color:#41cf2e;"></i></div>
              <h4 class="title"><a href="">Magni Dolores</a></h4>
              <p class="description">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mt-5">
            <div class="icon-box" data-aos="zoom-in-left" data-aos-delay="400">
              <div class="icon"><i class="bi bi-globe" style="color: #d6ff22;"></i></div>
              <h4 class="title"><a href="">Nemo Enim</a></h4>
              <p class="description">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mt-5">
            <div class="icon-box" data-aos="zoom-in-left" data-aos-delay="500">
              <div class="icon"><i class="bi bi-clock" style="color: #4680ff;"></i></div>
              <h4 class="title"><a href="">Eiusmod Tempor</a></h4>
              <p class="description">Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi</p>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio">
      <div class="container">

        <div class="section-title" data-aos="zoom-out">
          <h2>Portfolio</h2>
          <p>Filmes</p>
        </div>

        <ul id="portfolio-flters" class="d-flex justify-content-end" data-aos="fade-up">
          <li data-filter="*" class="filter-active">All</li>
          <li data-filter=".filter-romance">Romance</li>
          <li data-filter=".filter-terror">Terror</li>
          <li data-filter=".filter-acao">Ação</li>
          <li data-filter=".filter-ficcao">Ficção</li>
          <li data-filter=".filter-animacao">Animação</li>
        </ul>

        <div class="row portfolio-container" data-aos="fade-up">
        <style>
          .portfolio-img img {
          width: 400px;
          height: 550px;
         
        }
       </style>
        <?php
          foreach ($romances as $romance):?>
            <div class="col-lg-4 col-md-6 portfolio-item filter-romance">
              <div class="portfolio-img">
                <img src="../assets/img/<?= $romance->getImagem()?>" class="img-fluid" alt="">
              </div>
              <div class="portfolio-info">
                <h4><?= $romance->getNome() ?></h4>
                <p><?= $romance->getGenero() ?></p>
              </div>
            </div>
        <?php endforeach; ?>
        <?php
          foreach ($horrores as $terror):?>
            <div class="col-lg-4 col-md-6 portfolio-item filter-terror">
              <div class="portfolio-img">
                <img src="../assets/img/<?= $terror->getImagem()?>" class="img-fluid" alt="">
              </div>
              <div class="portfolio-info">
                <h4><?= $terror->getNome() ?></h4>
                <p><?= $terror->getGenero() ?></p>
              </div>
            </div>
        <?php endforeach; ?>
        <?php
          foreach ($acoes as $acao):?>
            <div class="col-lg-4 col-md-6 portfolio-item filter-acao">
              <div class="portfolio-img">
                <img src="../assets/img/<?= $acao->getImagem()?>" class="img-fluid" alt="">
              </div>
              <div class="portfolio-info">
                <h4><?= $acao->getNome() ?></h4>
                <p><?= $acao->getGenero() ?></p>
              </div>
            </div>
        <?php endforeach; ?>
        <?php
          foreach ($ficcoes as $ficcao):?>
            <div class="col-lg-4 col-md-6 portfolio-item filter-ficcao">
              <div class="portfolio-img">
                <img src="../assets/img/<?= $ficcao->getImagem()?>" class="img-fluid" alt="">
              </div>
              <div class="portfolio-info">
                <h4><?= $ficcao->getNome() ?></h4>
                <p><?= $ficcao->getGenero() ?></p>
              </div>
            </div>
        <?php endforeach; ?>
        <?php
          foreach ($animacoes as $animacao):?>
            <div class="col-lg-4 col-md-6 portfolio-item filter-animacao">
              <div class="portfolio-img">
                <img src="../assets/img/<?= $animacao->getImagem()?>" class="img-fluid" alt="">
              </div>
              <div class="portfolio-info">
                <h4><?= $animacao->getNome() ?></h4>
                <p><?= $animacao->getGenero() ?></p>
              </div>
            </div>
        <?php endforeach; ?>
          <div class="col-lg-4 col-md-6 portfolio-item filter-terror">
            <div class="portfolio-img"><img src="../assets/img/portfolio/ahoradopesadelo.jpg" class="img-fluid" alt=""></div>
            <div class="portfolio-info">
              <h4>A hora do pesadelo (1984)</h4>
              <p>Terror</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-romance">
            <div class="portfolio-img"><img src="../assets/img/titanic.jpg" class="img-fluid" alt=""></div>
            <div class="portfolio-info">
              <h4>Titanic (1997)</h4>
              <p>Romance</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-acao">
            <div class="portfolio-img"><img src="../assets/img/clubedaluta.png" class="img-fluid" alt=""></div>
            <div class="portfolio-info">
              <h4>Clube da Luta(1999)</h4>
              <p>Ação</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-ficcao">
            <div class="portfolio-img"><img src="../assets/img/portfolio/matrix.jpg" class="img-fluid" alt=""></div>
            <div class="portfolio-info">
              <h4>Matrix (1999)</h4>
              <p>Ficção científica "Futuro próximo"</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-animacao">
            <div class="portfolio-img"><img src="../assets/img/portfolio/oreileao.jpg" class="img-fluid" alt=""></div>
            <div class="portfolio-info">
              <h4>O Rei Leão (1994)</h4>
              <p>Animação</p>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-animacao">
            <div class="portfolio-img"><img src="../assets/img/portfolio/brancade-neve.jpg" class="img-fluid" alt=""></div>
            <div class="portfolio-info">
              <h4>Branca De Neve(1937)</h4>
              <p>Animação</p>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-ficcao">
            <div class="portfolio-img"><img src="../assets/img/portfolio/devoltapfuturo1.jpg" class="img-fluid" alt=""></div>
            <div class="portfolio-info">
              <h4>De Volta Pro Futuro</h4>
              <p>Ficção científica</p>
           
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-img"><img src="../assets/img/portfolio/esqueceramdemim.jpg" class="img-fluid" alt=""></div>
            <div class="portfolio-info">
              <h4>Esqueceram De Mim (1990)</h4>
              <p>Comedia</p>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-ficcao">
            <div class="portfolio-img"><img src="../assets/img/portfolio/showdeTm.jpg" class="img-fluid" alt=""></div>
            <div class="portfolio-info">
              <h4>O show De Trueman (1998)</h4>
              <p> Ficção científica/Drama</p>
           
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Portfolio Section -->

    

    <!-- ======= Pricing Section ======= -->
    <section id="pricing" class="pricing">
      <div class="container">

        <div class="section-title" data-aos="zoom-out">
          <h2>Pricing</h2>
          <p>Ingressos</p>
        </div>

        <div class="row">

          <div class="col-lg-3 col-md-6">
            <div class="box" data-aos="zoom-in">
              <h3>Meia</h3>
              <h4><sup>R$</sup>15</h4>
              <ul>
                <li>Estudante</li>
                <li>Criança</li>
                <li>Idoso</li>
                <li>Deficiente</li>
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Buy Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-4 mt-md-0">
            <div class="box featured" data-aos="zoom-in" data-aos-delay="100">
              <h3>Inteira</h3>
              <h4><sup>R$</sup>30</h4>
              <ul>
              <li>Adulto</li>
              
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Buy Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-4 mt-lg-0">
            <div class="box" data-aos="zoom-in" data-aos-delay="200">
              <h3>Sala 3D</h3>
              <h4><sup>R$</sup>45</h4>
              <ul>
                <li>Três dimensões: largura, comprimento e profundidade.</li>
                <li>Maior precisão nos detalhes.</li>
                <li>Óculos com filtros polarizadores.</li>
               
                
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Buy Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-4 mt-lg-0">
            <div class="box" data-aos="zoom-in" data-aos-delay="300">
              <span class="advanced">Advanced</span>
              <h3>Sala VIP</h3>
              <h4><sup>R$</sup>60</h4>
              <ul>
                <li>Poltronas de couro reclináveis.</li>
                <li>Atendimento personalizado.</li>
                <li>Cardápio especial.</li>
                <li>Tecnologia de som e projeção.</li>
                
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Buy Now</a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Pricing Section -->

    <!-- ======= F.A.Q Section ======= -->
    <section id="faq" class="faq">
      <div class="container">

        <div class="section-title" data-aos="zoom-out">
          <h2>F.A.Q</h2>
          <p>Perguntas Frequentes</p>
        </div>

        <ul class="faq-list">

          <li>
            <div data-bs-toggle="collapse" class="collapsed question" href="#faq1">Crianças pagam meia entrada? <i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></div>
            <div id="faq1" class="collapse" data-bs-parent=".faq-list">
              <p>
              Crianças de 3 a 12 anos de idade incompletos tem a meia-entrada garantida mediante apresentação de documento de identidade. Crianças de 0 a 36 meses não pagam entrada desde que permaneçam na mesma poltrona do responsável.              </p>
            </div>
          </li>

          <li>
            <div data-bs-toggle="collapse" href="#faq2" class="collapsed question">Como funciona a compra antecipada dos meus ingressos? <i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></div>
            <div id="faq2" class="collapse" data-bs-parent=".faq-list">
              <p>
              Normalmente a compra antecipada dos ingressos, pode ser realizada diretamente nas bilheterias do CineMAFlix, com até 2 dias de antecedência. Para grandes lançamentos, realizamos a "venda antecipada" que pode acontecer até 30 dias antes do lançamento do filme. Você também pode comprar seus ingressos pelo site.              </p>
            </div>
          </li>

          <li>
            <div data-bs-toggle="collapse" href="#faq3" class="collapsed question">Como eu sei se um filme é dublado ou legendado na relação de salas e horários deste site? <i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></div>
            <div id="faq3" class="collapse" data-bs-parent=".faq-list">
              <p>
              São dublados todos os filmes estrangeiros que apresentam a indicação "Dub." ao lado dos horários de cada filme. São legendados todos os filmes estrangeiros que apresentam a indicação "Leg." ao lado dos horários de cada filme.              </p>
            </div>
          </li>

          <li>
            <div data-bs-toggle="collapse" href="#faq4" class="collapsed question">Quanto tempo um filme fica em cartaz? <i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></div>
            <div id="faq4" class="collapse" data-bs-parent=".faq-list">
              <p>
              Toda quinta-feira nossa programação sofre alterações com a estreia de novos filmes. A permanência de um título depende de alguns fatores, sendo um deles a procura do público pelo filme. Em alguns casos, é necessário que um filme saia de cartaz para a entrada de outro lançamento.              </p>
            </div>
          </li>

          <li>
            <div data-bs-toggle="collapse" href="#faq5" class="collapsed question">Há algum dia promocional? <i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></div>
            <div id="faq5" class="collapse" data-bs-parent=".faq-list">
              <p>
              Nós temos nossa promoção Super Quarta, na qual todas as sessões de quarta-feira serão meias-entradas. (Não valido para sessões de pré-estreias)              </p>
            </div>
          </li>

          <li>
            <div data-bs-toggle="collapse" href="#faq6" class="collapsed question">Como comprovar a meia estudantil?<i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></div>
            <div id="faq6" class="collapse" data-bs-parent=".faq-list">
              <p>
              Aceitamos a Carteira de Identificação Estudantil (CIE), comprovante de matrícula ou atestado de frequência atualizados, todos apresentados juntamente com a identidade.              </p>
            </div>
          </li>

        </ul>

      </div>
    </section><!-- End F.A.Q Section -->

    <!-- ======= Team Section ======= -->
    <section id="team" class="team">
      <div class="container">

        <div class="section-title" data-aos="zoom-out">
          <h2>Team</h2>
          <p>Our Hardworking Team</p>
        </div>

        <div class="row">

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up">
              <div class="member-img">
                <img src="../assets/img/team/ianft.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Ian Abacherli</h4>
                <span>Programador junior</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" data-aos-delay="100">
              <div class="member-img">
                <img src="../assets/img/team/lucasft.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Lucas Furtunato</h4>
                <span>Programador chef</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" data-aos-delay="200">
              <div class="member-img">
                <img src="../assets/img/team/rayssaft.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Rayssa Mara</h4>
                <span>Programadora junior</span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Team Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <h3>CineMAFlix</h3>
      <p>Et aut eum quis fuga eos sunt ipsa nihil. Labore corporis magni eligendi fuga maxime saepe commodi placeat.</p>
      <div class="social-links">
        <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
        <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
      <div class="copyright">
        &copy; Copyright <strong><span>CineMAFlix</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/selecao-bootstrap-template/ -->
        Designed by <a href="https://www.instagram.com/ian_abacherli/">Ian Abacherli</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>

</body>

</html>