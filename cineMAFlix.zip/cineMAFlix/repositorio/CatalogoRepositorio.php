<?php
class FilmeRepositorio
{
    private $conn; // Sua conexão com o banco de dados
    public function __construct($conn)
    {
        $this->conn = $conn;
    }
    public function cadastrar(Filme $filme)
    {
        $sql = "INSERT INTO filmes (genero, nome, sinopse, 
        imagem) VALUES (?,?,?,?,?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param(
            "ssssd",
            $filme->getGenero(),
            $filme->getNome(),
            $filme->getSinopse(),
            $filme->getImagemDiretorio(),
            $filme->getPreco()
        );

        // Executa a consulta preparada e verifica o sucesso
        $success = $stmt->execute();

        // Fecha a declaração
        $stmt->close();

        // Retorna um indicador de sucesso
        return $success;
    }


    public function listarAlmocos()
    {
        $sql = "SELECT * FROM filmes where genero = 'Almoço' 
        ORDER BY preco";
        $result = $this->conn->query($sql);

        $filmes = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $filme = new Filme(
                    $row['id'],
                    $row['genero'],
                    $row['nome'],
                    $row['sinopse'],$row['preco'],
                    $row['imagem']
                    
                );
                $filmes[] = $filme;
            }
        }

        return $filmes;
    }
    public function atualizarFilme(Filme $filme)
    {
        if (empty($filme->getImagem())) {
            // Prepara a declaração SQL
            $sql = "UPDATE filmes SET genero = ?, nome = ?,
            sinopse = ?,  preco = ? WHERE id = ?";
            $stmt = $this->conn->prepare($sql);

            // Extrai os atributos do objeto Filme
            $genero = $filme->getGenero();
            $nome = $filme->getNome();
            $sinopse = $filme->getSinopse();

            $preco = $filme->getPreco();
            $id = $filme->getId();

            // Vincula os parâmetros
            $stmt->bind_param(
                'sssdi',
                $genero,
                $nome,
                $sinopse,

                $preco,
                $id
            );
            // Executa a declaração preparada
            $resultado = $stmt->execute();

            // Fecha a declaração
            $stmt->close();

            return $resultado;
        } else {
            // Prepara a declaração SQL
            $sql = "UPDATE filmes SET genero = ?, nome = ?,
            sinopse = ?, imagem = ?, preco = ? WHERE id = ?";

            $stmt = $this->conn->prepare($sql);
            // Extrai os atributos do objeto Filme
            $genero = $filme->getGenero();
            $nome = $filme->getNome();
            $sinopse = $filme->getSinopse();
            $imagem = $filme->getImagemDiretorio();
            $preco = $filme->getPreco();
            $id = $filme->getId();

            // Vincula os parâmetros
            $stmt->bind_param(
                'ssssdi',
                $genero,
                $nome,
                $sinopse,
                $imagem,
                $preco,
                $id
            );
            // Executa a declaração preparada
            $resultado = $stmt->execute();

            // Fecha a declaração
            $stmt->close();

            return $resultado;
        }
    }

    public function listarAlmocoPorId($id)
    {
        $sql = "SELECT * FROM filmes WHERE genero = 'Almoço' 
            AND id = ? ORDER BY preco LIMIT 1";

        // Prepara a declaração SQL
        $stmt = $this->conn->prepare($sql);

        // Vincula o parâmetro
        $stmt->bind_param('i', $id);

        // Executa a consulta preparada
        $stmt->execute();

        // Obtém os resultados
        $result = $stmt->get_result();

        $filme = null;

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            $filme = new Filme(
                $row['id'],
                $row['genero'],
                $row['nome'],
                $row['sinopse'],$row['preco'],
                $row['imagem']
                
            );
        }

        // Fecha a declaração
        $stmt->close();

        return $filme;
    }
    public function listarCafePorId($id)
    {
        $sql = "SELECT * FROM filmes WHERE genero = 'Café' 
            AND id = ? ORDER BY preco LIMIT 1";

        // Prepara a declaração SQL
        $stmt = $this->conn->prepare($sql);

        // Vincula o parâmetro
        $stmt->bind_param('i', $id);

        // Executa a consulta preparada
        $stmt->execute();

        // Obtém os resultados
        $result = $stmt->get_result();

        $filme = null;

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            $filme = new Filme(
                $row['id'],
                $row['genero'],
                $row['nome'],
                $row['sinopse'],$row['preco'],
                $row['imagem']
                
            );
        }

        // Fecha a declaração
        $stmt->close();

        return $filme;
    }

    public function excluirFilmePorId($id)
    {
        $sql = "DELETE FROM filmes WHERE  
             id = ?";

        // Prepara a declaração SQL
        $stmt = $this->conn->prepare($sql);

        // Vincula o parâmetro
        $stmt->bind_param('i', $id);

        // Executa a consulta preparada
        $success = $stmt->execute();

        // Fecha a declaração
        $stmt->close();

        return $success;
    }


    public function listarCafes()
    {
        $sql = "SELECT * FROM filmes where genero = 'Café' 
        ORDER BY preco";
        $result = $this->conn->query($sql);

        $filmes = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $filme = new Filme(
                    $row['id'],
                    $row['genero'],
                    $row['nome'],
                    $row['sinopse'],
                    $row['preco'],
                    $row['imagem']
                    
                );
                $filmes[] = $filme;
            }
        }

        return $filmes;
    }

    public function buscarTodos()
    {
        $sql = "SELECT * FROM filmes ORDER BY genero, preco";
        $result = $this->conn->query($sql);

        $filmes = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $filme = new Filme(
                    $row['id'],
                    $row['genero'],
                    $row['nome'],
                    $row['sinopse'],$row['preco'],
                    $row['imagem']
                    
                );
                $filmes[] = $filme;
            }
        }

        return $filmes;
    }
}
