<?php

class Filme {
    
    private ?int $id;  
    private string $genero;    
    private string $nome;    
    private string $sinopse;    
    private string $imagem;
    
    public function __construct(?int $id, 
                                string $genero, 
                                string $nome, 
                                string $sinopse, 
                                string $imagem = "")
    {
        $this->id = $id;
        $this->genero = $genero;
        $this->nome = $nome;
        $this->sinopse = $sinopse;
        $this->imagem = $imagem;
    }

    /**
     * Get the value of id
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId(?int $id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of genero
     */
    public function getGenero(): string
    {
        return $this->genero;
    }

    /**
     * Set the value of genero
     */
    public function setGenero(string $genero): self
    {
        $this->genero = $genero;

        return $this;
    }

    /**
     * Get the value of nome
     */
    public function getNome(): string
    {
        return $this->nome;
    }

    /**
     * Set the value of nome
     */
    public function setNome(string $nome): self
    {
        $this->nome = $nome;

        return $this;
    }

    /**
     * Get the value of sinopse
     */
    public function getSinopse(): string
    {
        return $this->sinopse;
    }

    /**
     * Set the value of sinopse
     */
    public function setSinopse(string $sinopse): self
    {
        $this->sinopse = $sinopse;

        return $this;
    }

    /**
     * Get the value of imagem
     */
    public function getImagem(): string
    {
        return $this->imagem;
    }

    public function getImagemDiretorio(): string
    {
        return "../css/img/".$this->imagem;
    }

    /**
     * Set the value of imagem
     */
    public function setImagem(string $imagem): self
    {
        $this->imagem = $imagem;

        return $this;
    }
}
?>