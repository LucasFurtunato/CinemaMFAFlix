<?php
require "../repositorio/conexao.php";
require "../modelo\Catalogo.php";
require "../repositorio\CatalogoRepositorio.php";

//if (isset($_POST['cadastro'])){ ou
if ($_SERVER["REQUEST_METHOD"]=="POST"){
    $nome = $_POST["nome"];
    $genero = $_POST["genero"];
    $sinopse = $_POST["sinopse"];
    $imagem = $_POST["imagem"];
    
    $produto = new Filme(0,
        $genero,
        $nome,
        $sinopse,
        $imagem
    );

    $filmeRepositorio = new FilmeRepositorio($conn);
    $filmeRepositorio->cadastrar($produto);
    header("Location: ../visao/cadastrar-filmes-sucesso.php");
}
